ovmain(a)
char *a;
{
	printf("in ov1. %s\n", a);
	return(1);
}

