ovmain(a)
char *a;
{
	printf("in ov2. %s\n", a);
	return(2);
}

